// Agrega estas rutas al routing que YA existe. No reemplaces el interceptor ni el routing del grupo.
// {
//   path: 'vehiculos',
//   loadComponent: () => import('./features/vehiculos/vehiculos.component').then(m => m.VehiculosComponent)
// },
// {
//   path: 'clientes',
//   loadComponent: () => import('./features/clientes/clientes.component').then(m => m.ClientesComponent)
// },
// {
//   path: 'ventas',
//   loadComponent: () => import('./features/ventas/ventas.component').then(m => m.VentasComponent)
// },
// {
//   path: 'monedas',
//   loadComponent: () => import('./features/monedas/monedas.component').then(m => m.MonedasComponent)
// }
