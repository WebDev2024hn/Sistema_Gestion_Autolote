import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientesService, Cliente } from '../../services/clientes.service';

@Component({
  selector: 'app-clientes',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.css']
})
export class ClientesComponent implements OnInit {
  private service = inject(ClientesService);
  clientes: Cliente[] = [];
  historial: any[] = [];
  clienteSeleccionado?: Cliente;
  error = '';

  ngOnInit(): void {
    this.service.listar().subscribe({
      next: data => this.clientes = data,
      error: err => this.error = err?.error?.message || 'Error al cargar clientes'
    });
  }

  verHistorial(cliente: Cliente): void {
    if (!cliente.id) return;
    this.clienteSeleccionado = cliente;
    this.service.historial(cliente.id).subscribe({
      next: data => this.historial = data,
      error: err => this.error = err?.error?.message || 'Error al cargar historial'
    });
  }
}
