import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonedasService } from '../../services/monedas.service';

@Component({
  selector: 'app-monedas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './monedas.component.html',
  styleUrls: ['./monedas.component.css']
})
export class MonedasComponent implements OnInit {
  private service = inject(MonedasService);
  data: any;
  cargando = true;
  error = '';

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.cargando = true;
    this.service.obtenerMonedas().subscribe({
      next: data => { this.data = data; this.cargando = false; },
      error: err => { this.error = err?.error?.message || 'No se pudieron obtener las monedas'; this.cargando = false; }
    });
  }
}
