import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehiculosService, Vehiculo } from '../../services/vehiculos.service';

@Component({
  selector: 'app-vehiculos',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './vehiculos.component.html',
  styleUrls: ['./vehiculos.component.css']
})
export class VehiculosComponent implements OnInit {
  private service = inject(VehiculosService);
  vehiculos: Vehiculo[] = [];
  cargando = true;
  error = '';

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.cargando = true;
    this.service.listar().subscribe({
      next: data => { this.vehiculos = data; this.cargando = false; },
      error: err => { this.error = err?.error?.message || 'No se pudieron cargar los vehículos'; this.cargando = false; }
    });
  }

  eliminar(id?: number): void {
    if (!id || !confirm('¿Eliminar este vehículo?')) return;
    this.service.eliminar(id).subscribe({ next: () => this.cargar(), error: err => this.error = err?.error?.message || 'Error al eliminar' });
  }
}
