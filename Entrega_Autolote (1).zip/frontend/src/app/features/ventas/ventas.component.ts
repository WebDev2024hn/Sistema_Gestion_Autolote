import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VentasService, Venta } from '../../services/ventas.service';

@Component({
  selector: 'app-ventas',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ventas.component.html',
  styleUrls: ['./ventas.component.css']
})
export class VentasComponent implements OnInit {
  private service = inject(VentasService);
  ventas: Venta[] = [];
  error = '';

  nueva: Venta = { cliente_id: 0, vehiculo_id: 0, fecha: new Date().toISOString().slice(0,10), precio: 0, moneda: 'HNL', estado: 'COMPLETADA' };

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.service.listar().subscribe({
      next: data => this.ventas = data,
      error: err => this.error = err?.error?.message || 'Error al cargar ventas'
    });
  }

  guardar(): void {
    if (!this.nueva.cliente_id || !this.nueva.vehiculo_id || this.nueva.precio <= 0) {
      this.error = 'Complete cliente, vehículo y precio.';
      return;
    }
    this.service.crear(this.nueva).subscribe({
      next: () => {
        this.nueva = { cliente_id: 0, vehiculo_id: 0, fecha: new Date().toISOString().slice(0,10), precio: 0, moneda: 'HNL', estado: 'COMPLETADA' };
        this.cargar();
      },
      error: err => this.error = err?.error?.message || 'Error al crear la venta'
    });
  }

  eliminar(id?: number): void {
    if (!id || !confirm('¿Eliminar esta venta?')) return;
    this.service.eliminar(id).subscribe({ next: () => this.cargar(), error: err => this.error = err?.error?.message || 'Error al eliminar' });
  }
}
