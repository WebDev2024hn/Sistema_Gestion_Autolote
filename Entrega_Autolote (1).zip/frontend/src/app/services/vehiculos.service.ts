import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Vehiculo {
  id?: number;
  marca: string;
  modelo: string;
  anio: number;
  precio: number;
  estado?: string;
}

@Injectable({ providedIn: 'root' })
export class VehiculosService {
  private http = inject(HttpClient);
  private apiUrl = '/api/vehiculos';

  listar(): Observable<Vehiculo[]> { return this.http.get<Vehiculo[]>(this.apiUrl); }
  crear(data: Vehiculo): Observable<Vehiculo> { return this.http.post<Vehiculo>(this.apiUrl, data); }
  actualizar(id: number, data: Vehiculo): Observable<Vehiculo> { return this.http.put<Vehiculo>(`${this.apiUrl}/${id}`, data); }
  eliminar(id: number): Observable<void> { return this.http.delete<void>(`${this.apiUrl}/${id}`); }
}
