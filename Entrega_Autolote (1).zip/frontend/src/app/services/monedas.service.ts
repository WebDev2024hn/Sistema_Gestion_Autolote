import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

export interface Moneda {
  code: string;
  name: string;
  rate?: number;
}

@Injectable({ providedIn: 'root' })
export class MonedasService {
  private http = inject(HttpClient);

  // Se consume el endpoint interno para que la API externa quede centralizada en backend.
  obtenerMonedas(): Observable<any> {
    return this.http.get('/api/monedas');
  }
}
