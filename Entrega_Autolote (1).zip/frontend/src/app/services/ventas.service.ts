import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Venta {
  id?: number;
  cliente_id: number;
  vehiculo_id: number;
  fecha: string;
  precio: number;
  moneda: string;
  estado: string;
}

@Injectable({ providedIn: 'root' })
export class VentasService {
  private http = inject(HttpClient);
  private apiUrl = '/api/ventas';

  listar(): Observable<Venta[]> { return this.http.get<Venta[]>(this.apiUrl); }
  crear(data: Venta): Observable<Venta> { return this.http.post<Venta>(this.apiUrl, data); }
  actualizar(id: number, data: Venta): Observable<Venta> { return this.http.put<Venta>(`${this.apiUrl}/${id}`, data); }
  eliminar(id: number): Observable<void> { return this.http.delete<void>(`${this.apiUrl}/${id}`); }
}
