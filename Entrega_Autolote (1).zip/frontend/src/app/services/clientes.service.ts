import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Cliente {
  id?: number;
  nombre: string;
  email: string;
  telefono: string;
  direccion?: string;
}

@Injectable({ providedIn: 'root' })
export class ClientesService {
  private http = inject(HttpClient);
  private apiUrl = '/api/clientes';

  listar(): Observable<Cliente[]> { return this.http.get<Cliente[]>(this.apiUrl); }
  historial(id: number): Observable<any[]> { return this.http.get<any[]>(`${this.apiUrl}/${id}/historial`); }
}
