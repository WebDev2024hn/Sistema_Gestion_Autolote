# Entrega - Sistema Gestión Autolote

Incluye el trabajo solicitado:
1. Backend - Gestión de ventas
2. Frontend Angular - Vehículos
3. Frontend Angular - Clientes y consultas
4. Frontend Angular - Ventas
5. Frontend Angular - Monedas

## Rama
Crear desde develop:
git checkout develop
git pull origin develop
git checkout -b feature/ventas-vehiculos-clientes-monedas

## Importante
No se incluye ningún .env ni JWT secret. Usa las variables locales del proyecto del grupo.

## Integración
Los archivos están organizados para copiarse sobre la estructura existente:
- backend/ -> rutas, controlador y modelo de ventas
- frontend/src/app/features/ -> módulos/páginas
- frontend/src/app/services/ -> servicios HTTP

Los endpoints usados por defecto son:
- GET/POST/PUT/DELETE /api/vehiculos
- GET/POST/PUT/DELETE /api/clientes
- GET /api/clientes/:id/historial
- GET/POST/PUT/DELETE /api/ventas
- GET /api/monedas

Si el proyecto del grupo ya tiene servicios o rutas con nombres diferentes, conserva los existentes y adapta solamente la URL.
El interceptor JWT no se reemplaza.
