// Usa la conexión MySQL que ya tiene el proyecto.
// Ejemplo si todavía no existe config/database.js:
//
// const mysql = require('mysql2/promise');
// module.exports = mysql.createPool({
//   host: process.env.DB_HOST,
//   user: process.env.DB_USER,
//   password: process.env.DB_PASSWORD,
//   database: process.env.DB_NAME,
//   port: process.env.DB_PORT || 3306
// });
//
// No subas credenciales reales al repositorio.
