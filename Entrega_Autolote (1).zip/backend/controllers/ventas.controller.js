const db = require('../config/database');

async function listarVentas(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT v.*, c.nombre AS cliente_nombre
       FROM ventas v
       LEFT JOIN clientes c ON c.id = v.cliente_id
       ORDER BY v.id DESC`
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Error al consultar las ventas', error: error.message });
  }
}

async function obtenerVenta(req, res) {
  try {
    const [rows] = await db.query('SELECT * FROM ventas WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ message: 'Venta no encontrada' });
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Error al consultar la venta', error: error.message });
  }
}

async function crearVenta(req, res) {
  try {
    const { cliente_id, vehiculo_id, fecha, precio, moneda, estado } = req.body;

    if (!cliente_id || !vehiculo_id || precio == null) {
      return res.status(400).json({ message: 'cliente_id, vehiculo_id y precio son obligatorios' });
    }

    const [result] = await db.query(
      `INSERT INTO ventas (cliente_id, vehiculo_id, fecha, precio, moneda, estado)
       VALUES (?, ?, COALESCE(?, CURRENT_DATE), ?, COALESCE(?, 'HNL'), COALESCE(?, 'COMPLETADA'))`,
      [cliente_id, vehiculo_id, fecha || null, precio, moneda || 'HNL', estado || 'COMPLETADA']
    );

    const [rows] = await db.query('SELECT * FROM ventas WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Error al registrar la venta', error: error.message });
  }
}

async function actualizarVenta(req, res) {
  try {
    const { cliente_id, vehiculo_id, fecha, precio, moneda, estado } = req.body;

    const [result] = await db.query(
      `UPDATE ventas
       SET cliente_id = ?, vehiculo_id = ?, fecha = ?, precio = ?, moneda = ?, estado = ?
       WHERE id = ?`,
      [cliente_id, vehiculo_id, fecha, precio, moneda, estado, req.params.id]
    );

    if (!result.affectedRows) return res.status(404).json({ message: 'Venta no encontrada' });
    const [rows] = await db.query('SELECT * FROM ventas WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar la venta', error: error.message });
  }
}

async function eliminarVenta(req, res) {
  try {
    const [result] = await db.query('DELETE FROM ventas WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ message: 'Venta no encontrada' });
    res.json({ message: 'Venta eliminada correctamente' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar la venta', error: error.message });
  }
}

module.exports = {
  listarVentas,
  obtenerVenta,
  crearVenta,
  actualizarVenta,
  eliminarVenta
};
